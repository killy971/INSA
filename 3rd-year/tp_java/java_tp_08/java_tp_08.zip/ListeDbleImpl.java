public class ListeDbleImpl implements Liste {
    private Maillon tete,queue,ec;
    public ListeDbleImpl(){
	this.tete = new Maillon();
	this.queue = new Maillon();
	this.tete.setSuivant(queue);
	this.queue.setPrecedent(tete);
	this.ec=tete;
    }
    public boolean listeVide(){
	return tete.getSuivant()==queue && queue.getPrecedent()==tete;
    }
    public boolean aSuivant(){
	return !(ec.getSuivant()==queue);
    }
    public boolean aPrecedent(){
	return !(ec.getPrecedent()==tete);
    }
    public Object element() throws ExceptionListeVide{
	if (this.listeVide()) throw new  ExceptionListeVide();
	return ec.getValeur();
    }
    public void ajouter(Object o){
	Maillon m = new Maillon();
	m.setValeur(o);
	m.setPrecedent(ec);
	m.setSuivant(ec.getSuivant());
	this.ec.getSuivant().setPrecedent(m);
	this.ec.setSuivant(m);
	this.ec = m;
    }
    public void enlever() throws ExceptionListeVide{
	if (this.listeVide()) throw new ExceptionListeVide();
	ec.getPrecedent().setSuivant(ec.getSuivant());
	ec.getSuivant().setPrecedent(ec.getPrecedent());
	this.ec = ec.getPrecedent();
    }
    public void suivant() throws ExceptionHorsListe{
	if (!this.aSuivant()) throw new ExceptionHorsListe();
	this.ec = ec.getSuivant();
    }
    public void precedent() throws ExceptionHorsListe{
	if (!this.aPrecedent())throw new ExceptionHorsListe();
	this.ec = ec.getPrecedent();
    }

    public static void main(String args[]) {
	ListeDbleImpl l = new ListeDbleImpl();
	ListeDbleImpl l2 = new ListeDbleImpl();
	System.out.println(l.listeVide());
        l.ajouter(new Integer(1));
	System.out.println(l.listeVide());
	l.ajouter(new Integer(2));
	l.ajouter(new Integer(3));
	try {
	    l.precedent();
	    l.precedent();
	    System.out.println(l.aSuivant());
	    l.suivant();
	    l.suivant();
	    System.out.println(l.aPrecedent());
	    
	    l2.ajouter(new Integer(4));
	}
	catch(Exception e) {
	    System.out.println(e.getMessage());
	}
	try {
	    l2.precedent();
	}
	catch(Exception e) {
	    System.out.println(e.getMessage());
	}
	try {
	    l2.suivant();
	}
	catch(Exception e) {
	    System.out.println(e.getMessage());
	}
	try {
	    l2.enlever();
	    l2.enlever();
	}
	catch(Exception e) {
	    System.out.println(e.getMessage());
	}
	try {
	    l2.element();
	}
	catch(Exception e) {
	    System.out.println(e.getMessage());
	}
	try {
	    l2.ajouter(new Integer(7));
	    System.out.println(faible==l2.element());
	    l2.ajouter(new Integer(5));
	    l2.precedent();
	    System.out.println(l2.element());
	    
	}
	catch(Exception e) {
	    System.out.println(e.getMessage());
	}
    }
}