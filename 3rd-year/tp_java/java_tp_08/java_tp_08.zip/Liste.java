public interface Liste {
    public boolean listeVide();
    public boolean aSuivant();
    public boolean aPrecedent();
    public Object element() throws ExceptionListeVide;
    public void ajouter(Object o);
    public void enlever() throws ExceptionListeVide;
    public void suivant() throws ExceptionHorsListe;
    public void precedent() throws ExceptionHorsListe;
}// Liste