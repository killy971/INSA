public class Maillon {
    private Maillon suivant, precedent;
    private Object valeur;
    
    public Maillon() {}
    
    public Maillon getSuivant() { return this.suivant; }
    public void setSuivant(Maillon m) { this.suivant = m; }
    public Maillon getPrecedent() { return this.precedent; }
    public void setPrecedent(Maillon m) { this.precedent = m; }
    public Object getValeur() { return this.valeur; }
    public void setValeur(Object e) { this.valeur = e; }
    public String toString() {
	return "valeur (precendent,courant,suivant): "+(Integer)this.getPrecedent().getValeur()+","+(Integer)this.getValeur()+","+this.getSuivant().getValeur();
    }
    public static void main(String args[]) {
	Maillon m1 = new Maillon();
	Maillon m2 = new Maillon();
	Maillon m3 = new Maillon();
	m1.setValeur(new Integer(11));
	m2.setValeur(new Integer(12));
	m3.setValeur(new Integer(13));
	m2.setPrecedent(m1);
	m2.setSuivant(m3);
	System.out.println(m2);
    }
}// Maillon

/*

valeur (precendent,courant,suivant): 11,12,13

*/