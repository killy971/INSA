/**
 * 
 *@author Nargeot Guillaume
 *@author Leroy Vincent
 *@version TP 10 23/11/2004
 */

public class Enregistrement {
	
	private String nom;
	private Coordonnees coordonnees;
	private int population;
	
	public Enregistrement(String n, Coordonnees c, int p) {
		this.nom = n;
		this.coordonnees = c;
		this.population = p;
	}// Enregistrement()
	
	/**
	 * 
	 *@param 
	 *@return 
	 */
	public String nom() {
		return this.nom;
	}// nom()
	
	/**
	 * 
	 *@param 
	 *@return 
	 */
	public Coordonnees coordonnees() {
		return this.coordonnees;
	}// coordonnees()
	
	/**
	 * 
	 *@param 
	 *@return 
	 */
	public int population() {
		return this.population;
	}// population()
	
	/**
	 * 
	 *@param 
	 *@return 
	 */
	public float distance(Enregistrement e) {
		float xa,ya,xb,yb;
		xa = this.coordonnees.latitude();
		ya = this.coordonnees.longitude();
		xb = e.coordonnees.latitude();
		yb = e.coordonnees.longitude();
		return (float)java.lang.Math.sqrt((double)((xb-xa)*(xb-xa)+(yb-ya)*(yb-ya)));
	}// distance()
	
	/**
	 * 
	 *@param 
	 *@return 
	 */
	public String toString() {
		String s = "Nom: "+this.nom+"\n";
		s += this.coordonnees.toString()+"\n";
		s += "Population: "+this.population;
		return s;
	}// toString()
	
	/**
	 * 
	 *@param 
	 *@return 
	 */
	public boolean equals(Object o) {
		if (!(o instanceof Enregistrement)) {
			return false;
		}
		return    (this.nom.equals(((Enregistrement)o).nom))
				&&(this.coordonnees.equals(((Enregistrement)o).coordonnees))
				&&(this.population == ((Enregistrement)o).population);
	}
	
	public static void main(String args[]) {
		
		Enregistrement e1 = new Enregistrement("Basse-Terre",
		new Coordonnees(21,41),40000);
		System.out.println(e1);
		
	}
}