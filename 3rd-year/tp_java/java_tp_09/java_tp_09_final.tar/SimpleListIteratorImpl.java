	class SimpleListIteratorImpl implements SimpleListIterator {
		
		/**
		 * 
		 *@param 
		 *@return 
		 */
		public Object ec() throws SimpleListException {
			
		}// ec()
	
		/**
		 * 
		 *@param 
		 *@return 
		 */
		public boolean sorti() {
			
		}// sorti()
	
		/**
		 * 
		 *@param 
		 *@return 
		 */
		public void entete() {
			
		}// entete()
	
		/**
		 * 
		 *@param 
		 *@return 
		 */
		public void enqueue() {
			
		}// enqueue()
	
		/**
		 * 
		 *@param 
		 *@return 
		 */
		public void allera(int i) throws SimpleListException {
			
		}// allera()
	
		/**
		 * 
		 *@param 
		 *@return 
		 */
		public void suc() throws SimpleListException {
			
		}// suc()
	
		/**
		 * 
		 *@param 
		 *@return 
		 */
		public void pred() throws SimpleListException {
			
		}// pred()
	
		/**
		 * 
		 *@param 
		 *@return 
		 */
		public void inserer(Object obj) throws SimpleListException {
			
		}// inserer()
	
		/**
		 * 
		 *@param 
		 *@return 
		 */
		public void ajouter(Object obj) throws SimpleListException {
			
		}// ajouter()
	
		/**
		 * 
		 *@param 
		 *@return 
		 */
		public void oter() throws SimpleListException {
			
		}// oter()
	
		/**
		 * 
		 *@param 
		 *@return 
		 */
		public void modifier(Object obj) throws SimpleListException {
			
		}// modifier()
		
		public static void main(String args[]) {
			
			
			
		}// main()
		
	}