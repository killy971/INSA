class Rectangle {

    int x,y,l,h; 
    /* x,y  : abscisse et ordonnee du coin en haut a gauche du rectangle */
    /* l,h : longueur et hauteur du rectangle */

    /* Constructeur : initialise les variables x,y,l,h 
       d'apres les parametres */
    Rectangle(int px, int py, int pl, int ph) {
	x = px; y = py; l = pl; h = ph;
    }

    /* Retourne le perimetre du rectangle */
    int perimetre () {
	return (2*(l+h));
    }

    /* Retourne l'aire du rectangle */
    int aire () {
	return (l*h);
    }

    boolean memeAire (Rectangle r) {
	int airer;
	airer = r.aire();
	if (airer == l*h) return true; else return false;
    }
}
