import Rectangle;

public class TestRectangle {
    public static void main(String[] args) {
                Rectangle r;

		/* Creation d'un nouveau rectangle */
		r = new Rectangle(5,5,3,7);

		/* Affichage default son perimetre */
		System.out.print("perimetre = ");
                System.out.println(r.perimetre());

		/* Affichage de son aire */
		System.out.print("aire = ");
		System.out.println(r.aire());

		/* Test de la fonction qui teste l'egalite des aires */
		if (r.memeAire(r)) System.out.println("Meme aire fonctionne");
        }
}
