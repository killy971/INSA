public class Carte {
  
    private int  hauteur;
    private int  couleur;
 
 public Carte(int h, int c){
    couleur=c;
    hauteur=h;
  }// constructeur Carte 

  public boolean inf(Carte c){
      return this.hauteur < c.hauteur;
  }//inf

    public boolean memeHauteur(Carte c){
	return this.hauteur == c.hauteur;
    }//memeNiveau

  public String toString(){
   String[] tabCouleur={"Trefle","Carreau","Coeur","Pique"};
   String[] tabHauteur={"7","8","9","10","Valet","Dame","Roi","As"};
  return "(" +tabHauteur[hauteur]+" de "+tabCouleur[ couleur]+") ";
 }//toString

  
public static void main(String[] args){
System.out.println("debut\n");
Carte c1 = new Carte(0,3);
System.out.println(c1);
  }//main
    
}//Carte
   
