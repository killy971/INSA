========================================================================
    APPLICATION CONSOLE : vue d'ensemble du projet tp1
========================================================================

AppWizard a cr�� cette application tp1 pour vous.  
Ce fichier contient un r�sum� du contenu de chacun des fichiers qui
constituent votre application tp1.


tp1.vcproj
    Il s'agit du fichier projet principal pour les projets VC++ g�n�r�s en utilisant un Assistant Application. 
    Il contient les informations sur la version de Visual C++ qui a g�n�r� le fichier et 
    les informations sur les plates-formes, les configurations et les fonctionnalit�s du projet s�lectionn�es avec
    l'Assistant Application.

tp1.cpp
    Il s'agit du fichier source principal de l'application .

/////////////////////////////////////////////////////////////////////////////
Autres fichiers standard�:

StdAfx.h, StdAfx.cpp
    Ces fichiers sont utilis�s pour g�n�rer un fichier d'en-t�te pr�compil� (PCH) 
    nomm� tp1.pch et un fichier de type pr�compil� nomm� StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Autres remarques�:

AppWizard utilise des commentaires "TODO�:" pour indiquer les parties du code source o� vous
pouvez ajouter ou modifier du code.

/////////////////////////////////////////////////////////////////////////////
